
public class Database {
    public CustomList cs=new CustomList();
    public CustomerInfo ci=new CustomerInfo();
    public PetInfo pi=new PetInfo();
    public String customer;
}
