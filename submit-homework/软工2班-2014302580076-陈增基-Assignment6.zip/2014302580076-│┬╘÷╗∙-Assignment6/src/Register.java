import java.awt.AWTException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;


public class Register extends JFrame {
	private String btuser;
	private String btpw;
	private String btrpw;
	public Register(Database db) throws AWTException, IOException{
		 super("PetShop"); 	
		 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setBounds(300, 10, 450, 600);
			JPanel bmypanel=new JPanel();
			bmypanel.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(bmypanel);
			bmypanel.setLayout(null);
		 	JLabel title=new JLabel("ע��");
	    	bmypanel.add(title);
	    	title.setBounds(100,20, 100, 20);
	    	//field
	    	JLabel blabels[]=new JLabel[3];
	    	String[] bstr={"�û���","����","�ظ�����"};
	    	for(int i=0;i<3;i++){
	    		blabels[i]=new JLabel(bstr[i]);
		    	bmypanel.add(blabels[i]);
		    	blabels[i].setBounds(40,100+i*100, 100, 20);
	    	}
	    	//instruction
	    	JLabel blabels2[]=new JLabel[3];
	    	String[] bstr2={"����Ϊ3-6","����Ϊ8-18",""};
	    	for(int i=0;i<3;i++){
	    		blabels2[i]=new JLabel(bstr2[i]);
		    	bmypanel.add(blabels2[i]);
		    	blabels2[i].setBounds(260,100+i*100, 100, 20);
	    	}
	    	//input	    	
	    	JTextArea buser=new JTextArea();
	    	buser.setBounds(150, 100, 100, 20);
	    	bmypanel.add(buser);
	    	JTextArea bpwd=new JTextArea();
	    	bpwd.setBounds(150, 200, 100, 20);
	    	bmypanel.add(bpwd);
	    	JTextArea brpwd=new JTextArea();
	    	brpwd.setBounds(150, 300, 100, 20);
	    	bmypanel.add(brpwd);
	    	//button
	    	JButton bOK = new JButton("OK");
			bOK.setBounds(70, 400, 70, 50);
			bmypanel.add(bOK);
			bOK.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {				
					btuser=buser.getText();
					btpw=bpwd.getText();
					btrpw=brpwd.getText();
					if(btuser.length()>6||btuser.length()<3){
						False0 f404=new False0(db,"�û������Ȳ���",2);
						dispose();
						return;
					}
					for(int i=0;i<db.cs.names.length;i++){
						if(db.cs.names[i].equals(btuser)){
							False0 f404=new False0(db,"�û����Ѵ���",2);
							dispose();
							return;
						}							
					}
					if(btpw.length()>18||btpw.length()<8){
						False0 f404=new False0(db,"���볤�Ȳ���",2);
						dispose();
						return;
					}
						if(!btpw.equals(btrpw)){
						False0 f404=new False0(db,"�������벻���",2);
						dispose();
						return;}
				
							try {
								db.cs.Adding(btuser, btpw);
								 db.customer=btuser;
								   db.ci.Access(btuser);
								   db.cs.Access();
								   Goods goods=new Goods(db);
								   dispose();
							} catch (ClassNotFoundException | SQLException | AWTException | IOException e) {
								// TODO �Զ����ɵ� catch ��
								e.printStackTrace();
							}
					  
					
				
				}});
			JButton bback = new JButton("Back");
			bback.setBounds(180, 400, 70, 50);
			bmypanel.add(bback);
			bback.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {				
					try {
						Customer cs=new Customer(db);
					} catch (AWTException e) {
						// TODO �Զ����ɵ� catch ��
						e.printStackTrace();
					} catch (IOException e) {
						// TODO �Զ����ɵ� catch ��
						e.printStackTrace();
					}
					dispose();
				}});
			
			
			setVisible(true);
   }
}
