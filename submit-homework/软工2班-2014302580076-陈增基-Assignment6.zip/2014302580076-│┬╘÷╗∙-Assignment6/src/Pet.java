
public class Pet {

	private int id;

	public void getid(int id){this.id=id;}

	public int showid(){return id;}

	private String name;
	
	public void getname(String name){this.name=name;}
	
	public String showname(){return name;}
	
	private String eat;
	
	public void geteat(String eat){this.eat=eat;}
	
	public String showeat(){return eat;}
	
	private String drink;

	public void getdrink(String drink){this.drink=drink;}
	
	public String showdrink(){return drink;}
	
	private String live;

	public void getlive(String live){this.live=live;}
	
	public String showlive(){return live;}
	
	private String hobby;

	public void gethobby(String hobby){this.hobby=hobby;}
	
	public String showhobby(){return hobby;}
	
	private int money;

	public void getmoney(int money){this.money=money;}

	public int showmoney(){return money;}

	private String introduce;

	public void getintro(String introduce){this.introduce=introduce;}
	
	public String showintro(){return introduce;}
	

}
