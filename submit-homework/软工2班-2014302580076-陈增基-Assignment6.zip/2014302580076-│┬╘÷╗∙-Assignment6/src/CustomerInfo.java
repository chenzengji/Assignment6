import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class CustomerInfo {
	public String[] carts;
	public int count=0;
	private Connection conn;
	private Statement statement;
	private String customer;
	public void Access(String customer)throws ClassNotFoundException{
		this.customer=customer;
		if(this.customer.equals(""))return;
		 Class.forName("com.mysql.jdbc.Driver");
		 ResultSet rs ;
			try {
				conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");					
				statement=conn.createStatement();	
				try{	
				  rs=statement.executeQuery("select *from 2014302580076_cm_"+customer);
				}catch(SQLException e){
					String sql="  create table 2014302580076_cm_"+customer+" ("
							+ "cart varchar(255) NOT NULL "
							+") ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;";							
				 statement.executeUpdate(sql);
				 sql="INSERT INTO 2014302580076_cm_"+customer+" VALUES ('0')";
				 statement.executeUpdate(sql);
				 System.out.println(775);
				 rs=statement.executeQuery("select *from 2014302580076_cm_"+customer);
				}
				count=0;
				while(rs.next()){count++;}			
				carts=new String[count];
				count=0;
				rs=statement.executeQuery("select *from 2014302580076_cm_"+customer);
				while(rs.next()){                
                      carts[count]=rs.getString("cart");			    		
					     count++;
					     }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

           }
	public void adding(String name) throws SQLException{
			    String sql="INSERT INTO 2014302580076_cm_"+customer+" VALUES('"+name+"')";
			    statement.executeUpdate(sql);			  
			    ResultSet rs=statement.executeQuery("select *from 2014302580076_cm_"+customer);
			    count=0;
				while(rs.next()){count++;}			
				carts=new String[count];
				count=0;
				rs=statement.executeQuery("select *from 2014302580076_cm_"+customer);
				while(rs.next()){                
					 carts[count]=rs.getString("cart");
				     count++;
					     }
	}
	public void cancel(int tpt) throws SQLException{
		   String sql="delete from 2014302580076_cm_"+customer;  
			statement.executeUpdate(sql);
			for(int i=0;i<carts.length;i++){ 
				if(i==tpt)continue;
			sql="INSERT INTO 2014302580076_cm_"+customer+" VALUES ('"+carts[i]+"')";
			 statement.executeUpdate(sql);
			 }
			
			
		    ResultSet rs=statement.executeQuery("select *from 2014302580076_cm_"+customer);
		    count=0;
			while(rs.next()){count++;}			
			carts=new String[count];
			count=0;
			rs=statement.executeQuery("select *from 2014302580076_cm_"+customer);
			while(rs.next()){                
				 carts[count]=rs.getString("cart");
				 count++;
					    }
		
	}
	public void charge(int tpi) throws SQLException{
		   String sql="delete from 2014302580076_cm_"+customer;  
			statement.executeUpdate(sql);
			sql="INSERT INTO 2014302580076_cm_"+customer+" VALUES ('"+String.format("%d", Integer.parseInt(carts[0])+tpi)+"')";
			 statement.executeUpdate(sql);
			for(int i=1;i<carts.length;i++){ 				
			sql="INSERT INTO 2014302580076_cm_"+customer+" VALUES ('"+carts[i]+"')";
			 statement.executeUpdate(sql);
			 }
		    ResultSet rs=statement.executeQuery("select *from 2014302580076_cm_"+customer);
		    count=0;
			while(rs.next()){count++;}			
			carts=new String[count];
			count=0;
			rs=statement.executeQuery("select *from 2014302580076_cm_"+customer);
						while(rs.next()){                
							 carts[count]=rs.getString("cart");
						     count++;
							     }
		
	}
	public void pay(int rest) throws SQLException{
		String sql="delete from 2014302580076_cm_"+customer;  
		statement.executeUpdate(sql);
		sql="INSERT INTO 2014302580076_cm_"+customer+" VALUES ('"+String.format("%d", rest)+"')";
		 statement.executeUpdate(sql);
		    ResultSet rs=statement.executeQuery("select *from 2014302580076_cm_"+customer);
		    count=0;
			while(rs.next()){count++;}			
			carts=new String[count];
			count=0;
			rs=statement.executeQuery("select *from 2014302580076_cm_"+customer);
						while(rs.next()){                
							 carts[count]=rs.getString("cart");
						     count++;
							     }
		
	}

}
