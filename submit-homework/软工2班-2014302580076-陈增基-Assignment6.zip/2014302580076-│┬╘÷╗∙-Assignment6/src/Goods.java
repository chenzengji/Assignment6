import java.awt.AWTException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;


public class Goods extends JFrame{
	private String csscreen;
	private int cpt;
	private String cname="";
	private boolean next;
	private Database db;
	public Goods(Database db) throws AWTException, IOException{
		 super("PetShop");
		 this.db=db;
		 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setBounds(300, 10, 800, 800);
			
			JPanel cmypanel=new JPanel();
			cmypanel.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(cmypanel);
			cmypanel.setLayout(null);
		 	JLabel ctitle=new JLabel("Goods");
	    	cmypanel.add(ctitle);
	    	ctitle.setBounds(100,20, 100, 20);
	    	JLabel cwl=new JLabel("Hello , "+db.customer);
	    	cmypanel.add(cwl);
	    	cwl.setBounds(400,20, 100, 20);
	    	//show info
	        JTextArea cif=new JTextArea();
	        cif.setEditable(false);	
	        cif.setBounds(40, 40, 400, 300);
	    	cmypanel.add(cif);
	    	//show cart
	    	JLabel cscart=new JLabel(String.format("����%d����Ʒ�ڹ��ﳵ��",db.ci.carts.length-1));
	    	cscart.setBounds(460,80,150,20);
	    	cmypanel.add(cscart);
	    	//show money
	    	JLabel csmoney=new JLabel("����"+db.ci.carts[0]+"Ԫ");
	    	csmoney.setBounds(460, 120,100,20);
	    	cmypanel.add(csmoney);
	    	
	    	int total=0;
	    	for(int i=1;i<db.ci.carts.length;i++){
	    		if(i==1)total=0;
	    		for(int j=0;j<db.pi.pets.length;j++){
	    			if(db.pi.pets[j].showname().equals(db.ci.carts[i]))
	    				total+=  db.pi.pets[j].showmoney();
	    		}
	    	}
	    	//show total
	    	JLabel cstotal=new JLabel("���ﳵ��Ʒ�ܼ�"+String.format("%d", total)+"Ԫ");
	    	cstotal.setBounds(460, 160,150,20);
	    	cmypanel.add(cstotal);
	    	//show introduce
	    	JLabel csintro=new JLabel("���ﳵ����������Ʒ");
	    	csintro.setBounds(460, 40, 150, 20);
	    	cmypanel.add(csintro);
	    	//list
	    	JButton cpetlist[]=new JButton[db.pi.pets.length];
	    	
	    	for( int i=0;i<db.pi.pets.length;i++){
	    		addbutton(cpetlist[i],i, cmypanel, cif);
	    	}
	    	
	        //put into cart
	    	JButton cpcart = new JButton("Add Goods");
	    	cpcart.setBounds(500,400,100,50);
	    	cmypanel.add(cpcart);
	    	cpcart.addActionListener(
	    			new ActionListener(){
	    				public void actionPerformed(ActionEvent event)
	    				{   
	    					next=false;
	    					if(cname.equals("")){
	    						False0 f404=new False0(db,"�㻹δѡ��",3);
						        dispose();
						        return;
						        }
	    					if(db.ci.carts.length<6)next=true;
	    					if(next){
	    						try {
									db.ci.adding(cname);
									Goods goods=new Goods(db);
									dispose();
								} catch (SQLException  | IOException | AWTException e) {
									// TODO �Զ����ɵ� catch ��
									e.printStackTrace();
								}
	    					}
	    					else {
	    						False0 f404=new False0(db,"���ﳵ����",3);
							    dispose();
							    return;
							    }
	    				}});
	       	  //enter cart
	    	JButton ccart = new JButton("into cart");
	    	ccart.setBounds(100,620,90,50);
	    	cmypanel.add(ccart);
	    	ccart.addActionListener(
	    			new ActionListener(){
	    				public void actionPerformed(ActionEvent event)
	    				{
	    					Cart cart=new Cart(db);
	    					dispose();
	    				}
	    			});
	  	  //enter log out
	    	JButton clogout = new JButton("Log Out");
	    	clogout.setBounds(200,620,90,50);
	    	cmypanel.add(clogout);
	    	clogout.addActionListener(
	    			new ActionListener(){
	    				public void actionPerformed(ActionEvent event)
	    				{
	    					try {
								Customer cs=new Customer(db);
							} catch (AWTException e) {
								// TODO �Զ����ɵ� catch ��
								e.printStackTrace();
							} catch (IOException e) {
								// TODO �Զ����ɵ� catch ��
								e.printStackTrace();
							}
	    					dispose();
	    				}
	    			});
	    	
	    	
			setVisible(true);

	
	    	 
	   }
	public void addbutton(JButton button,int i,JPanel cmypanel,JTextArea cif){
		button=new JButton(db.pi.pets[i].showname());
		button.setBounds(40+110*(i%4),380+70*(i/4),90,50);
   	    cmypanel.add(button);    
   	    button.addActionListener(
   			 new ActionListener(){
   				 public void actionPerformed(ActionEvent event)
   			    	{   cname=db.pi.pets[i].showname(); 					    
   		  			 csscreen="name:      "+db.pi.pets[i].showname()+"\n"+
   	  				          "eat:       "+db.pi.pets[i].showeat()+"\n"+
   		            		  "drink:     "+db.pi.pets[i].showdrink()+"\n"+
   			  		          "live:      "+db.pi.pets[i].showlive()+"\n"+
   				  	          "hobby:     "+db.pi.pets[i].showhobby()+"\n"+
   	     			          "introduce: "+db.pi.pets[i].showintro()+"\n"+
   					          "price:     "+String.format("%d",db.pi.pets[i].showmoney()) ;
   		  			 cif.setText(csscreen);
   			    	}}); 
	}
}
