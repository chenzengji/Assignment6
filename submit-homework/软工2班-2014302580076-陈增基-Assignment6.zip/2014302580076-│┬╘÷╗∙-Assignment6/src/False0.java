import java.awt.AWTException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


public class False0 extends JFrame{
	public False0(Database db,String tf,int type){
		 super("PetShop"); 			 
		 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setBounds(300, 10, 450, 600);

		 
		 
			JPanel 	tmypanel=new JPanel();
			tmypanel.setBorder(new EmptyBorder(5, 5, 5, 5));		
			setContentPane(tmypanel);
			tmypanel.setLayout(null);
			
		 	JLabel atitle=new JLabel("����");
	    	tmypanel.add(atitle);
	    	atitle.setBounds(100,20, 100, 20);
	    	//
	    	JLabel ttf=new JLabel(tf);
		    	tmypanel.add(ttf);
		    	ttf.setBounds(150,200, 200, 50);
	    	
	    	
	    	JButton tback = new JButton("Back");
			tback.setBounds(200, 400, 70, 50);
			tmypanel.add(tback);
			tback.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {	
					try {
					switch(type){
				       case 1:  Customer cs=new Customer(db);break;
				       case 2:Register rg=new Register(db);break;
				       case 3:  Goods good=new Goods(db);break;
				       case 4:Cart cart=new Cart(db);break;
				       
				     }
					} catch (AWTException | IOException e) {
						// TODO �Զ����ɵ� catch ��
						e.printStackTrace();
					}
					dispose();
				  
				}});
			setVisible(true);
	}

}
