import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class CustomList {
	public String[] names;
	public String[] passwords;
	public int count=0;
	private Connection conn;
	private Statement statement;
	public void Access()throws ClassNotFoundException{
		 Class.forName("com.mysql.jdbc.Driver");
		 ResultSet rs ;
			try {
			    conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");					
				statement=conn.createStatement();	
				try{	
				  rs=statement.executeQuery("select *from 2014302580076_customerlist");
				}catch(SQLException e){
					String sql="create table 2014302580076_customerlist("
							+ "id int(11) primary key NOT NULL AUTO_INCREMENT,"
							+ "name varchar(255) NOT NULL,"
							+ "password varchar(255) NOT NULL"
							+") ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;";							
				 statement.executeUpdate(sql);
				 rs=statement.executeQuery("select *from 2014302580076_customerlist");
				}
				count=0;
				while(rs.next()){count++;}
			
			
				names=new String[count];
				passwords=new String[count];
				count=0;
				
				 rs=statement.executeQuery("select *from 2014302580076_customerlist");
			
				while(rs.next()){
                      int id=rs.getInt("id");                 
                       int pid=id-1;
                       if(count<id)count=id;
  
					     names[pid]=rs.getString("name");
					     passwords[pid]=rs.getString("password");
					     }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	
	}
	public void Adding(String cm,String pw)throws ClassNotFoundException, SQLException{

			    String sql="INSERT INTO 2014302580076_customerlist VALUES('"+String.format("%d",count+1)+"','"+cm+"','"+pw+"')";
			    statement.executeUpdate(sql);				
			}
	


}
