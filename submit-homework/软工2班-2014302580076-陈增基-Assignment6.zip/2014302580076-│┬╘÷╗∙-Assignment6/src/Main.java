import java.awt.AWTException;
import java.io.IOException;

import javax.swing.SwingUtilities;


public class Main {
	public static void main(String[] args) throws AWTException, IOException, ClassNotFoundException {
		Database db =new Database();
		db.cs.Access();
		db.pi.Access();
		Customer cs=new Customer(db);
	
			
	}
}
