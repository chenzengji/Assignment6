import javax.swing.JFrame;


public class Wallet extends JFrame {

}
