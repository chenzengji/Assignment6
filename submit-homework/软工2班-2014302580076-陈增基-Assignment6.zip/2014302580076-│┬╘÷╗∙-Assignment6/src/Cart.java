import java.awt.AWTException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;


public class Cart extends JFrame{
	public void addconcel(JButton dcancel,int i,Database db,JPanel dmypanel){
		dcancel=new JButton(String.format("%d", i+1));
		dcancel.setBounds(70+80*(i%4),300+60*(i/4),70,50);
   	  dmypanel.add(dcancel);    
   	dcancel.addActionListener(
   			 new ActionListener(){
   				 public void actionPerformed(ActionEvent event)
   			    	{    					    
   					try {
						db.ci.cancel(i+1);
						Cart cart=new Cart(db);
						dispose();
					} catch (SQLException e) {
						// TODO �Զ����ɵ� catch ��
						e.printStackTrace();
					}		        					      					  
   			    	}}); 
	}
	public void addmoney(JButton dcharge,int i,int money,JPanel dmypanel,Database db){
		dcharge=new JButton(String.format("%d", money));
		dcharge.setBounds(70+i*80,500,70,50);
   	  dmypanel.add(dcharge);    	
   	dcharge.addActionListener(
   			 new ActionListener(){
   				 public void actionPerformed(ActionEvent event)
   				 {
   					 try {
						db.ci.charge(money);
						Cart cart=new Cart(db);
						dispose();
					} catch (SQLException e) {
						// TODO �Զ����ɵ� catch ��
						e.printStackTrace();
					}
   				 }});
	}
	private int theprice(String pet,Database db){
		for(int i=0;i<db.pi.pets.length;i++){
			if(db.pi.pets[i].showname().equals(pet))
				return  db.pi.pets[i].showmoney();
		}
		return -1;
	}
	public Cart(Database db){
	 super("PetShop"); 	
	 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 10, 800, 800);
		JPanel dmypanel=new JPanel();
		dmypanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(dmypanel);
		dmypanel.setLayout(null);
		setVisible(true);
	 	JLabel dtitle=new JLabel("Cart");
    	dmypanel.add(dtitle);
    	dtitle.setBounds(100, 20, 100, 20);
    	JLabel dwl=new JLabel("Hello , "+db.customer);
    	dmypanel.add(dwl);
    	dwl.setBounds(400,20, 100, 20);
    	//show info
    	String context="";
    	int total=0;
    	for(int i=1;i<db.ci.carts.length;i++){
    		if(i==1)total=0;
    		int itp=theprice(db.ci.carts[i],db);
    		context+=String.format("%d", i)+"  "+db.ci.carts[i]+"  price:"+String.format("%d", itp)+"\n";
            total+=itp;
    	}
        if(context.equals(""))context="��δ������Ʒ�����ﳵ��";
        else context+="total:"+String.format("%d", total);
    	JTextArea dif=new JTextArea(context);
        dif.setEditable(false);	
        dif.setBounds(40, 40, 400, 200);
    	dmypanel.add(dif);
    	//show cart
    	JLabel dscart=new JLabel(String.format("����%d����Ʒ�ڹ��ﳵ��",db.ci.carts.length-1));
    	dscart.setBounds(480,60,200,40);
    	dmypanel.add(dscart);
    	//show money
    	JLabel dsmoney=new JLabel("��������"+db.ci.carts[0]+"Ԫ");
    	dsmoney.setBounds(480,160,200,40);
    	dmypanel.add(dsmoney);
    	//show introduce
    	JLabel dsintro=new JLabel("ѡ���㲻��Ҫ����Ʒ��Ű�ť���ɳ���");
    	dsintro.setBounds(50,260, 250, 20);
    	dmypanel.add(dsintro);
    	//concel list
    	JLabel dcc=new JLabel("ѡ��ȡ������Ʒ��");
    	dcc.setBounds(50, 280, 200, 20);
    	dmypanel.add(dcc);
    	JButton dcancels[]=new JButton[db.ci.carts.length-1];
    	for( int i=0;i<db.ci.carts.length-1;i++){
    		addconcel(dcancels[i],i,db,dmypanel);
    		setVisible(true);
    	}
      //money list
    	JLabel dsintro2=new JLabel("ѡ����Ҫ��ֵ��Ǯ��");
    	dsintro2.setBounds(50,450, 200, 20);
    	dmypanel.add(dsintro2);
    	JLabel dccc=new JLabel("��Ҫ��ֵ����");
    	dccc.setBounds(50, 470, 100, 20);
    	dmypanel.add(dccc);
    	JButton dcharges[]=new JButton[4];
    	int[] money={100,300,500,1000};
    	for( int i=0;i<4;i++){
    		addmoney(dcharges[i],i, money[i],dmypanel,db);
    		setVisible(true);
    	}

       	  //return goods
    	JButton dgoods = new JButton("Return Goods");
    	dgoods.setBounds(80,570,150,50);
    	dmypanel.add(dgoods);
    	dgoods.addActionListener(
    			new ActionListener(){
    				public void actionPerformed(ActionEvent event)
    				{
    					try {
							Goods goods=new Goods(db);
						} catch (AWTException | IOException e) {
							// TODO �Զ����ɵ� catch ��
							e.printStackTrace();
						}
    					
    					dispose();
    				}});
  	  //pay money
    	JButton dpay = new JButton("Pay");
    	dpay.setBounds(270,570,70,50);
    	dmypanel.add(dpay);
    	dpay.addActionListener(
    			new ActionListener(){
    				public void actionPerformed(ActionEvent event)
    				{
    					if(db.ci.carts.length==1){return;}
    				  int dcash=Integer.parseInt(db.ci.carts[0]);
    					for(int i=1;i<db.ci.carts.length;i++){
    						for(int j=0;j<db.pi.pets.length;j++){
    							if(db.ci.carts[i].equals(db.pi.pets[j].showname())) 
    								dcash-=db.pi.pets[j].showmoney();   								
    						}
    					}
    					if(dcash>=0)
							try {
								db.ci.pay(dcash);
								Cart cart=new Cart(db);
								dispose();
							} catch (SQLException e) {
								// TODO �Զ����ɵ� catch ��
								e.printStackTrace();
							}
    					else{
    						False0 f404=new False0(db,"����",4);
						dispose();
						return;
						}
    				}});
    	   
		setVisible(true);
  	  	
}
	
}
