import java.awt.AWTException;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;


public class Customer extends JFrame{
	private String atuser;
	private String atpw;
	private boolean next;
	public Customer(Database db) throws AWTException, IOException{
		 super("PetShop"); 			 
		 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setBounds(300, 10, 450, 600);

		 
		 
			JPanel 	amypanel=new JPanel();
			amypanel.setBorder(new EmptyBorder(5, 5, 5, 5));		
			setContentPane(amypanel);
			amypanel.setLayout(null);
			
		 	JLabel atitle=new JLabel("��¼");
	    	amypanel.add(atitle);
	    	atitle.setBounds(100,20, 100, 20);
	    	//
	    	JLabel alabels[]=new JLabel[2];
	    	String[] astr={"�û���","����"};
	    	for(int i=0;i<2;i++){
	    		alabels[i]=new JLabel(astr[i]);
		    	amypanel.add(alabels[i]);
		    	alabels[i].setBounds(40,100+i*100, 100, 20);
	    	}
	    	JTextArea auser=new JTextArea();
	    	auser.setBounds(150, 100, 100, 20);
	    	amypanel.add(auser);
	    	JTextArea apwd=new JTextArea();
	    	apwd.setBounds(150, 200, 100, 20);
	    	amypanel.add(apwd);
	    	JButton alogin = new JButton("Login");
			alogin.setBounds(60, 300, 70, 50);
			amypanel.add(alogin);
			alogin.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {				
					atuser=auser.getText();
					atpw=apwd.getText();
					next=false;
					for(int i=0;i<db.cs.names.length;i++){
						if(db.cs.names[i].equals(atuser)){
							if(db.cs.passwords[i].equals(atpw))next=true;
							break;
						}							
					}
					if(next){						
						try {
							db.customer=atuser;
							db.ci.Access(atuser);
							Goods goods=new Goods(db);
							dispose();
						} catch (ClassNotFoundException | AWTException | IOException e) {
							// TODO �Զ����ɵ� catch ��
							e.printStackTrace();
						}
					}
					else{
						False0 f404=new False0(db,"�û������������",1);
						dispose();
					}
				}});
			JButton aregist = new JButton("Regist");
			aregist.setBounds(160, 300, 70, 50);
			amypanel.add(aregist);
			aregist.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {	
					
						try {
							Register rg=new Register(db);
						} catch (AWTException | IOException e) {
							 System.out.println("55555");
							e.printStackTrace();
						}
					
					
					dispose();
				  
				}});
			
			
		//	add(amypanel);
			setVisible(true);
			
			
			
		
			}


	
}
