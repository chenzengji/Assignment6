import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class PetInfo {
	public Pet pets[];
	public int count=0;
	public void Access()throws ClassNotFoundException{
		 Class.forName("com.mysql.jdbc.Driver");
		 ResultSet rs = null;
			try {
				Connection conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");					
				Statement statement=conn.createStatement();	
				try{	
				  rs=statement.executeQuery("select *from 2014302580076_pet");
				}catch(SQLException e){
					String sql=" create table 2014302580076_pet("
							+ "  id int(11) primary key NOT NULL AUTO_INCREMENT,"
							+ "  name varchar(255) NOT NULL ,"
							+ "  eat varchar(255) NOT NULL ,"
							+ "  drink varchar(255) NOT NULL ,"
							+ "  live varchar(255) NOT NULL ,"
							+ "  hobby varchar(255) NOT NULL ,"							
							+ "  cost int(11) NOT NULL , "
							+ "  introduce varchar(255) NOT NULL "
							+ ") ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;";							
				 statement.executeUpdate(sql);
				     sql="INSERT INTO 2014302580076_pet VALUES"
				     		+ " (1,'dog','bone','water','ground','play',200,'null'),"
				     		+ "(2,'cat','fish','milk','roof','hug',200,'null'),"
				     		+ "(3,'turtle','fish,shrimp','sea water','sea water','bask',400,'null'),"
				     		+ "(4,'parrot','nuts,seeds','water','tree','fly',500,'null'),"
				     		+ "(5,'hamster','Sunflower seed','water','corner','eat',150,'null'),"
				     		+ "(6,'squirrel','pine cone','water','tree hole,underground','play',300,'null'),"
				     		+ "(7,'rabbit','carrot','water','grassland,underground','eat',180,'null'),"
				     		+ "(8,'snake','mouse','water','hole','bask',700,'null'),"
				     		+ "(9,'lizard','bug','water','tree','bask',700,'null'),"
				     		+ "(10,'fish','aquatic plant','water','water','swim',250,'null'),"
				     		+ "(11,'myna','earthworm','water','tree','fly',320,'null'),"
				     		+ "(12,'canary','millet','water','tree','sing',340,'null');";
				     statement.executeUpdate(sql);
				          rs=statement.executeQuery("select *from 2014302580076_pet");
				}
				count=0;
				while(rs.next()){count++;}
				pets=new Pet[count];
				count=0;
				  rs=statement.executeQuery("select *from 2014302580076_pet");
				while(rs.next()){
                     int id=rs.getInt("id");                 
                      int pid=id-1;
                      pets[pid]=new Pet();
					     pets[pid].getname(rs.getString("name"));
					     pets[pid].geteat(rs.getString("eat"));
					     pets[pid].getdrink(rs.getString("drink"));
					     pets[pid].getlive(rs.getString("live"));
					     pets[pid].gethobby(rs.getString("hobby"));	
					     pets[pid].getmoney(rs.getInt("cost"));
					     pets[pid].getintro(rs.getString("introduce"));					 
					     count++;					   
					     }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
}
	public void add() {}	


}
